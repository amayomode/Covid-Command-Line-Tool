# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['covtool']

package_data = \
{'': ['*'], 'covtool': ['.pytest_cache/*', '.pytest_cache/v/cache/*', 'data/*']}

install_requires = \
['beautifulsoup4>=4.9.1,<5.0.0',
 'click-help-colors>=0.8,<0.9',
 'click>=7.1.2,<8.0.0',
 'lxml>=4.5.2,<5.0.0',
 'matplotlib>=3.3.1,<4.0.0',
 'pandas>=1.1.2,<2.0.0',
 'pyarrow>=1.0.1,<2.0.0',
 'pyfiglet>=0.8.post1,<0.9',
 'requests>=2.24.0,<3.0.0',
 'tabulate>=0.8.7,<0.9.0',
 'termcolor>=1.1.0,<2.0.0']

entry_points = \
{'console_scripts': ['covtool = covtool.cli:main']}

setup_kwargs = {
    'name': 'covtool',
    'version': '0.1.0',
    'description': 'covtool- A CLI For Getting Info About COVID19',
    'long_description': "## COVID COMMAND LINE TOOL\n\n### 1. WHY\n\nSo may of these covid tools exist online and I made this one for the sake of learning an also because browsing the web for data is a pain. (Why waste 10 minutes searching for contents when I can spend 3 hours automating the process 😅)\n\n### 2. WHAT\n\nThis tool fetches data about the COVID 19\n\n### 3. USAGE\n\n#### Screenshots\n\n![Sample 1](https://github.com/amayomode/Covid-Command-Line-Tool/blob/master/screenshots/screenshot1.PNG)\n\n![Sample 2](https://github.com/amayomode/Covid-Command-Line-Tool/blob/master/screenshots/screenshot2.PNG)\n\n![Sample 3](https://github.com/amayomode/Covid-Command-Line-Tool/blob/master/screenshots/screenshot3.PNG)\n\n#### Commands\n\n```bash\nUsage: covtool.py [OPTIONS] COMMAND [ARGS]...\n\nOptions:\n  --version  Show the version and exit.\n  --help     Show this message and exit.\n\nCommands:\n  get           Get Covid Data\n  info          Information About The Tool\n  plot-country  Plot Country's Time Series Plot by catergory i.e...\n  plot-global   Plot Global Time Series Plot by catergory i.e...\n  update        Updates Cached Dataset\n\n```\n\n> Blockquote\n\n#### 1. get\n\nShows the different cartegories of covid related data\n\n**_Example_**\n\n```bash\n python covtool.py get --world\n```\n\n```bash\nTotalCases: 29,029,976\nNewCases: +98,561\nTotalDeaths: 925,690\nNewDeaths: +1,610\nTotalRecovered: 20,892,634\nNewRecovered: +92,445\nActiveCases: 7,211,652\nSerious,Critical: 60,898\nTotalCases/1M pop: 3,724\nDeaths/1M pop: 118.8\n```\n\n```bash\n python covtool.py get --country Russia\n```\n\n```bash\nTotalCases: 1,062,811\nNewCases: +5,449\nTotalDeaths: 18,578\nNewDeaths: +94\nTotalRecovered: 876,225\nNewRecovered: +2,690\nActiveCases: 168,008\nSerious,Critical: 2,300\nTotalCases/1M pop: 7,282\nDeaths/1M pop: 127\n\n```\n\n> Options:\n> -w, --world Get World-Wide Covid Numbers\n> -j, --json Print the Data in Json Format\n> -c, --country TEXT Get a Country's Covid Numbers\n\n#### 2. plot-global\n\n```bash\nUsage: covtool.py plot-global [OPTIONS]\n                              [[recovered|confirmed|deaths]]\n\n  Plot Global Time Series Plot by catergory i.e recovered|confirmed|deaths\n  e.g covtool.py plot-global confirmed\n\nOptions:\n  --help  Show this message and exit.\n```\n\n**_Example_**\n\n```bash\n python covtool.py plot-global recovered\n```\n\n![Global recovered cases](https://github.com/amayomode/Covid-Command-Line-Tool/blob/master/screenshots/screenshot4.PNG)\n\n#### 3. plot-country\n\n```bash\nUsage: covtool.py plot-country [OPTIONS]\n                               [[recovered|confirmed|deaths]]\n\n  Plot Country's Time Series Plot by catergory i.e\n  recovered|confirmed|deaths e.g covtool.py plot-county -n US recovered\n\nOptions:\n  -n, --name TEXT  Name of the Country  [required]\n  --help           Show this message and exit.\n\n```\n\n**_Example_**\n\n```bash\n  python covtool.py plot-country --name Kenya confirmed\n```\n\n![Country Specific Cases](https://github.com/amayomode/Covid-Command-Line-Tool/blob/master/screenshots/screenshot5.PNG)\n\n#### 4. update\n\n```bash\nUsage: covtool.py update\n```\n\nUpdates locally cached dataset\n\n#### 5. Info\n\n```bash\nUsage: covtool.py info [OPTIONS]\n\n  Information About The Tool\n\nOptions:\n  --help  Show this message and exit.\n\n```\n\nUpdates locally cached dataset\n\n![Country Specific Cases](https://github.com/amayomode/Covid-Command-Line-Tool/blob/master/screenshots/screenshot6.PNG)\n\n#### 4. INSTALLATION\n\nTo try it out, if you want to, then:\n\n```bash\npipenv install setuptools\npipenv install  -e git+https://github.com/amayomode/Covid-Command-Line-Tool.git#egg=covtool\n```\n\nThen you can run any command as follows\n\n```bash\npipenv run <insert command here>\n```\n",
    'author': 'Amayo II',
    'author_email': 'amayomordecai@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/amayomode/Covid-Command-Line-Tool',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.1',
}


setup(**setup_kwargs)
